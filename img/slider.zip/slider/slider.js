var inner = document.querySelector('.slider-inner-container');
var image = document.querySelector(".image");
var n = 0;
var sliderWidth = document.getElementsByTagName("IMG").length;
var a=0;
var auto = setInterval(autoMove, 3000);
// sliding
function move(x){
    if(x == 1){
        n-= 100;
        inner.style.left = n + "%";
        a++;
                if(a >= sliderWidth){
            a=0;
            n= a * 100;
            inner.style.left = n + "%";
        }
    }
    else if(x == 2){
        n += 100;
        inner.style.left = n + "%";
        a--;
        if(a <= 0){
            a=sliderWidth;
            n = (a-1) * -100;
            inner.style.left = n + "%";
        }
        }
}
// Autoplay
function autoMove(){
    document.getElementsByClassName("arrow")[1].click();
}
document.getElementsByClassName('slider-container')[0].addEventListener("mouseover", function() {
    clearInterval(auto);
})   
document.getElementsByClassName('slider-container')[0].addEventListener("mouseleave", function() {
        auto = setInterval(autoMove, 3000);
});
// Sliding with keyboard
document.onkeydown = checkKey;

function checkKey(e) {

    e = e || window.event;

    if (e.keyCode == '39') {
        alert();
    }
   
    else if (e.keyCode == '37') {
       alert('yleo')
    }
 
}



